-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 28, 2018 at 08:34 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `paanchajanya`
--

-- --------------------------------------------------------

--
-- Table structure for table `event1`
--

CREATE TABLE IF NOT EXISTS `event1` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `member1` int(11) NOT NULL,
  `member2` int(11) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `event1`
--

INSERT INTO `event1` (`groupid`, `member1`, `member2`) VALUES
(8, 1000, 2000),
(2, 400, 400),
(3, 700, 800),
(7, 100, 200),
(5, 556, 788),
(6, 450, 350);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `event1` varchar(5) NOT NULL,
  `event2` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event1`, `event2`) VALUES
('yes', ''),
('yes', '');
